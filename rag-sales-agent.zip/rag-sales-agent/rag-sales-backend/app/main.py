from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
import json
import re
import os
from dotenv import load_dotenv
from .database import get_db, create_tables, ChatHistory, LeadQualification, TechnicalGuidance, PricingEstimate

load_dotenv()

app = FastAPI(
    title="RAG Sales Agent API",
    description="API for RAG application sales support with lead qualification, technical guidance, and Azure pricing",
    version="1.0.0"
)

# Disable CORS. Do not remove this for full-stack development.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

class ChatMessage(BaseModel):
    message: str
    context: Optional[str] = None

class ChatResponse(BaseModel):
    response: str
    suggestions: List[str] = []
    category: str
    confidence: float

class LeadQualificationRequest(BaseModel):
    company_name: str
    industry: str
    use_case: str
    data_volume: str
    timeline: str
    budget_range: str

class LeadQualificationResponse(BaseModel):
    score: int
    qualification_status: str
    recommendations: List[str]
    next_steps: List[str]

class TechnicalGuidanceRequest(BaseModel):
    question: str
    current_setup: Optional[str] = None
    requirements: Optional[str] = None

class PricingRequest(BaseModel):
    data_volume_gb: float
    queries_per_month: int
    storage_duration_months: int
    high_availability: bool = False
    backup_retention_days: int = 7

AZURE_VECTOR_DB_KNOWLEDGE = {
    "postgresql_pgvector": {
        "description": "Azure Database for PostgreSQL with pgvector extension for vector similarity search",
        "use_cases": ["Document search", "Semantic similarity", "Recommendation systems"],
        "pricing_tiers": ["Basic", "General Purpose", "Memory Optimized"],
        "features": ["ACID compliance", "High availability", "Automated backups", "Point-in-time restore"],
        "integration": "Native LangChain support via PostgreSQL connector"
    },
    "cognitive_search": {
        "description": "Azure Cognitive Search with vector search capabilities",
        "use_cases": ["Full-text search", "Hybrid search", "Knowledge mining"],
        "pricing_tiers": ["Free", "Basic", "Standard", "Storage Optimized"],
        "features": ["AI enrichment", "Semantic search", "Vector search", "Faceted navigation"]
    },
    "cosmos_db": {
        "description": "Azure Cosmos DB with vector search support",
        "use_cases": ["Global distribution", "Multi-model data", "Real-time applications"],
        "pricing_tiers": ["Serverless", "Provisioned throughput", "Autoscale"],
        "features": ["Multi-region replication", "Automatic indexing", "Vector indexing"]
    }
}

LANGCHAIN_KNOWLEDGE = {
    "azure_integrations": [
        "Azure OpenAI Service integration",
        "Azure Cognitive Search connector",
        "Azure Blob Storage document loader",
        "Azure Database for PostgreSQL vector store",
        "Azure Container Instances for deployment"
    ],
    "common_patterns": [
        "RAG with Azure OpenAI + PostgreSQL pgvector",
        "Document processing with Azure Form Recognizer",
        "Hybrid search with Cognitive Search",
        "Multi-modal RAG with Azure Computer Vision"
    ]
}

PRICING_CALCULATOR = {
    "postgresql": {
        "basic": {"cpu": 1, "memory": 2, "storage_gb": 32, "price_per_hour": 0.017},
        "general_purpose": {"cpu": 2, "memory": 4, "storage_gb": 128, "price_per_hour": 0.068},
        "memory_optimized": {"cpu": 2, "memory": 16, "storage_gb": 128, "price_per_hour": 0.136}
    },
    "cognitive_search": {
        "basic": {"search_units": 1, "storage_gb": 2, "price_per_hour": 0.25},
        "standard": {"search_units": 3, "storage_gb": 25, "price_per_hour": 1.01}
    },
    "openai": {
        "gpt_35_turbo": {"price_per_1k_tokens": 0.002},
        "gpt_4": {"price_per_1k_tokens": 0.03},
        "ada_002_embedding": {"price_per_1k_tokens": 0.0001}
    }
}

@app.on_event("startup")
async def startup_event():
    create_tables()

@app.get("/healthz")
async def healthz():
    return {"status": "ok"}

@app.post("/api/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatMessage, db: Session = Depends(get_db)):
    """
    General chat endpoint that routes questions to appropriate handlers
    """
    try:
        message = request.message.lower()
        
        if any(word in message for word in ["qualify", "lead", "company", "budget", "timeline"]):
            category = "lead_qualification"
            response = handle_lead_qualification_chat(request.message)
        elif any(word in message for word in ["price", "cost", "pricing", "budget", "estimate"]):
            category = "pricing"
            response = handle_pricing_chat(request.message)
        elif any(word in message for word in ["technical", "vector", "database", "postgresql", "langchain", "setup"]):
            category = "technical"
            response = handle_technical_chat(request.message)
        else:
            category = "general"
            response = handle_general_chat(request.message)
        
        chat_record = ChatHistory(
            session_id=request.context or "default",
            message=request.message,
            response=response["response"],
            category=category,
            confidence=response.get("confidence", 0.8)
        )
        db.add(chat_record)
        db.commit()
        
        return ChatResponse(
            response=response["response"],
            suggestions=response.get("suggestions", []),
            category=category,
            confidence=response.get("confidence", 0.8)
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Chat processing error: {str(e)}")

@app.post("/api/qualify-lead", response_model=LeadQualificationResponse)
async def qualify_lead(request: LeadQualificationRequest, db: Session = Depends(get_db)):
    """
    Qualify leads based on company information and RAG requirements
    """
    try:
        score = calculate_lead_score(request)
        
        if score >= 80:
            status = "Hot Lead"
            recommendations = [
                "Schedule technical deep-dive session",
                "Prepare custom RAG architecture proposal",
                "Connect with Azure solutions architect"
            ]
            next_steps = [
                "Technical requirements gathering",
                "POC planning session",
                "Pricing proposal preparation"
            ]
        elif score >= 60:
            status = "Warm Lead"
            recommendations = [
                "Provide RAG use case examples",
                "Share Azure vector database comparison",
                "Schedule follow-up in 2 weeks"
            ]
            next_steps = [
                "Send technical resources",
                "Budget discussion",
                "Timeline clarification"
            ]
        else:
            status = "Cold Lead"
            recommendations = [
                "Nurture with educational content",
                "Share RAG success stories",
                "Quarterly check-in"
            ]
            next_steps = [
                "Add to nurture campaign",
                "Send monthly newsletters",
                "Monitor for buying signals"
            ]
        
        lead_record = LeadQualification(
            company_name=request.company_name,
            industry=request.industry,
            use_case=request.use_case,
            data_volume=request.data_volume,
            timeline=request.timeline,
            budget_range=request.budget_range,
            score=score,
            qualification_status=status
        )
        db.add(lead_record)
        db.commit()
        
        return LeadQualificationResponse(
            score=score,
            qualification_status=status,
            recommendations=recommendations,
            next_steps=next_steps
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Lead qualification error: {str(e)}")

@app.post("/api/technical-guidance")
async def get_technical_guidance(request: TechnicalGuidanceRequest):
    """
    Provide technical guidance on Azure vector databases and LangChain
    """
    try:
        question = request.question.lower()
        guidance = {}
        
        if "postgresql" in question or "pgvector" in question:
            guidance = {
                "recommendation": "Azure Database for PostgreSQL with pgvector extension",
                "setup_steps": [
                    "Create Azure Database for PostgreSQL Flexible Server",
                    "Enable pgvector extension: CREATE EXTENSION vector;",
                    "Create vector column: ALTER TABLE documents ADD COLUMN embedding vector(1536);",
                    "Create vector index: CREATE INDEX ON documents USING ivfflat (embedding vector_cosine_ops);",
                    "Configure LangChain PostgreSQL vector store"
                ],
                "langchain_code": """
from langchain.vectorstores import PGVector
from langchain.embeddings import OpenAIEmbeddings

CONNECTION_STRING = "postgresql://user:pass@host:5432/dbname"
embeddings = OpenAIEmbeddings()
vectorstore = PGVector(
    connection_string=CONNECTION_STRING,
    embedding_function=embeddings,
)
""",
                "best_practices": [
                    "Use appropriate vector dimensions (1536 for OpenAI embeddings)",
                    "Choose right index type (IVFFlat for < 1M vectors, HNSW for > 1M)",
                    "Monitor query performance and adjust index parameters",
                    "Implement connection pooling for production workloads"
                ]
            }
        elif "cognitive search" in question:
            guidance = {
                "recommendation": "Azure Cognitive Search for hybrid vector + text search",
                "setup_steps": [
                    "Create Azure Cognitive Search service",
                    "Define search index with vector fields",
                    "Configure semantic search capabilities",
                    "Set up indexers for data ingestion",
                    "Integrate with LangChain AzureSearch connector"
                ],
                "features": [
                    "Hybrid search (vector + keyword)",
                    "Semantic ranking",
                    "AI enrichment pipeline",
                    "Auto-scaling capabilities"
                ]
            }
        elif "langchain" in question:
            guidance = {
                "azure_integrations": LANGCHAIN_KNOWLEDGE["azure_integrations"],
                "common_patterns": LANGCHAIN_KNOWLEDGE["common_patterns"],
                "sample_architecture": {
                    "components": [
                        "Azure OpenAI (embeddings + chat)",
                        "Azure Database for PostgreSQL (vector storage)",
                        "Azure Blob Storage (document storage)",
                        "Azure Container Apps (hosting)"
                    ],
                    "data_flow": [
                        "Documents → Azure Blob Storage",
                        "Processing → Azure Functions",
                        "Embeddings → Azure OpenAI",
                        "Storage → PostgreSQL pgvector",
                        "Retrieval → LangChain RAG pipeline"
                    ]
                }
            }
        else:
            guidance = {
                "general_advice": "For RAG applications on Azure, consider these key components:",
                "components": list(AZURE_VECTOR_DB_KNOWLEDGE.keys()),
                "decision_matrix": {
                    "postgresql_pgvector": "Best for: ACID compliance, complex queries, existing PostgreSQL expertise",
                    "cognitive_search": "Best for: Hybrid search, AI enrichment, enterprise search scenarios",
                    "cosmos_db": "Best for: Global distribution, multi-model data, serverless scaling"
                }
            }
        
        return {"guidance": guidance, "status": "success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Technical guidance error: {str(e)}")

@app.post("/api/pricing-estimate")
async def get_pricing_estimate(request: PricingRequest, db: Session = Depends(get_db)):
    """
    Calculate Azure service pricing for RAG applications
    """
    try:
        estimate = calculate_azure_pricing(request)
        
        pricing_record = PricingEstimate(
            data_volume_gb=request.data_volume_gb,
            queries_per_month=request.queries_per_month,
            storage_duration_months=request.storage_duration_months,
            high_availability=request.high_availability,
            backup_retention_days=request.backup_retention_days,
            total_monthly_usd=estimate["total_monthly_usd"]
        )
        db.add(pricing_record)
        db.commit()
        
        return {
            "monthly_estimate": estimate,
            "breakdown": estimate["breakdown"],
            "recommendations": estimate["recommendations"],
            "scaling_considerations": estimate["scaling_notes"]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Pricing calculation error: {str(e)}")

def calculate_lead_score(request: LeadQualificationRequest) -> int:
    """Calculate lead qualification score based on multiple factors"""
    score = 0
    
    high_value_industries = ["technology", "finance", "healthcare", "retail", "manufacturing"]
    if request.industry.lower() in high_value_industries:
        score += 20
    
    strong_use_cases = ["customer support", "document search", "knowledge management", "recommendation"]
    if any(use_case in request.use_case.lower() for use_case in strong_use_cases):
        score += 25
    
    if "tb" in request.data_volume.lower() or "petabyte" in request.data_volume.lower():
        score += 25
    elif "gb" in request.data_volume.lower():
        score += 15
    
    if "immediate" in request.timeline.lower() or "month" in request.timeline.lower():
        score += 20
    elif "quarter" in request.timeline.lower():
        score += 15
    
    if "100k" in request.budget_range or "million" in request.budget_range:
        score += 10
    
    return min(score, 100)

def handle_lead_qualification_chat(message: str) -> Dict[str, Any]:
    """Handle lead qualification related chat"""
    return {
        "response": "I can help you qualify leads for RAG applications. I'll need information about the company's industry, use case, data volume, timeline, and budget. Would you like to start with a formal lead qualification, or do you have specific questions about qualifying RAG prospects?",
        "suggestions": [
            "Start formal lead qualification",
            "What makes a good RAG prospect?",
            "Common RAG use cases by industry",
            "Budget considerations for RAG projects"
        ],
        "confidence": 0.9
    }

def handle_technical_chat(message: str) -> Dict[str, Any]:
    """Handle technical guidance chat"""
    if "postgresql" in message.lower():
        return {
            "response": "Azure Database for PostgreSQL with pgvector is excellent for RAG applications. It provides ACID compliance, strong consistency, and native vector similarity search. I can help you with setup, LangChain integration, or performance optimization. What specific aspect would you like to explore?",
            "suggestions": [
                "PostgreSQL pgvector setup guide",
                "LangChain integration examples",
                "Performance optimization tips",
                "Compare with other vector databases"
            ]
        }
    elif "langchain" in message.lower():
        return {
            "response": "LangChain has excellent Azure integrations for RAG applications. You can use Azure OpenAI for embeddings and chat, PostgreSQL for vector storage, and Cognitive Search for hybrid search. What specific integration are you interested in?",
            "suggestions": [
                "Azure OpenAI + LangChain setup",
                "PostgreSQL vector store integration",
                "Document processing pipeline",
                "Production deployment patterns"
            ]
        }
    else:
        return {
            "response": "I can provide technical guidance on Azure vector databases, LangChain integrations, and RAG architecture patterns. What specific technical challenge are you facing?",
            "suggestions": [
                "Vector database comparison",
                "Architecture recommendations",
                "Performance considerations",
                "Security best practices"
            ]
        }

def handle_pricing_chat(message: str) -> Dict[str, Any]:
    """Handle pricing related chat"""
    return {
        "response": "I can help estimate Azure costs for RAG applications including PostgreSQL, Cognitive Search, OpenAI services, and compute resources. To provide accurate pricing, I'll need details about your data volume, query frequency, and performance requirements. Would you like to start with a pricing estimate?",
        "suggestions": [
            "Get detailed pricing estimate",
            "Compare pricing tiers",
            "Cost optimization strategies",
            "Scaling cost considerations"
        ],
        "confidence": 0.85
    }

def handle_general_chat(message: str) -> Dict[str, Any]:
    """Handle general RAG sales chat"""
    return {
        "response": "I'm your RAG sales assistant, specialized in Azure vector databases, LangChain integrations, and pricing guidance. I can help with lead qualification, technical guidance, and cost estimation for RAG applications. How can I assist you today?",
        "suggestions": [
            "Qualify a new lead",
            "Get technical guidance",
            "Estimate project costs",
            "Learn about Azure vector databases"
        ],
        "confidence": 0.7
    }

def calculate_azure_pricing(request: PricingRequest) -> Dict[str, Any]:
    """Calculate comprehensive Azure pricing for RAG application"""
    
    if request.data_volume_gb <= 100:
        pg_tier = "basic"
    elif request.data_volume_gb <= 1000:
        pg_tier = "general_purpose"
    else:
        pg_tier = "memory_optimized"
    
    pg_config = PRICING_CALCULATOR["postgresql"][pg_tier]
    pg_monthly = pg_config["price_per_hour"] * 24 * 30
    
    storage_monthly = request.data_volume_gb * 0.115  # $0.115/GB/month
    
    backup_monthly = request.data_volume_gb * 0.095 * (request.backup_retention_days / 30)
    
    embedding_tokens = request.data_volume_gb * 1000 * 200  # Rough estimate
    embedding_cost = (embedding_tokens / 1000) * PRICING_CALCULATOR["openai"]["ada_002_embedding"]["price_per_1k_tokens"]
    
    query_tokens = request.queries_per_month * 1000  # Average tokens per query
    query_cost = (query_tokens / 1000) * PRICING_CALCULATOR["openai"]["gpt_35_turbo"]["price_per_1k_tokens"]
    
    ha_multiplier = 2 if request.high_availability else 1
    
    total_monthly = (pg_monthly + storage_monthly + backup_monthly) * ha_multiplier + embedding_cost + query_cost
    
    return {
        "total_monthly_usd": round(total_monthly, 2),
        "breakdown": {
            "postgresql_compute": round(pg_monthly * ha_multiplier, 2),
            "storage": round(storage_monthly, 2),
            "backup": round(backup_monthly, 2),
            "openai_embeddings": round(embedding_cost, 2),
            "openai_queries": round(query_cost, 2)
        },
        "recommendations": [
            f"Using {pg_tier} PostgreSQL tier for {request.data_volume_gb}GB data",
            "Consider reserved instances for 20-30% savings on compute",
            "Optimize embedding dimensions to reduce storage costs",
            "Implement caching to reduce OpenAI API calls"
        ],
        "scaling_notes": [
            "Costs scale linearly with data volume",
            "Query costs depend on user activity patterns",
            "Consider auto-scaling for variable workloads",
            "Monitor and optimize based on actual usage"
        ]
    }
