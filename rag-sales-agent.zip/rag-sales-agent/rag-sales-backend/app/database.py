import os
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, Float, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:password@localhost:5432/rag_sales_db")

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class ChatHistory(Base):
    __tablename__ = "chat_history"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String, index=True)
    message = Column(Text)
    response = Column(Text)
    category = Column(String)
    confidence = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)

class LeadQualification(Base):
    __tablename__ = "lead_qualifications"
    
    id = Column(Integer, primary_key=True, index=True)
    company_name = Column(String)
    industry = Column(String)
    use_case = Column(Text)
    data_volume = Column(String)
    timeline = Column(String)
    budget_range = Column(String)
    score = Column(Integer)
    qualification_status = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

class TechnicalGuidance(Base):
    __tablename__ = "technical_guidance"
    
    id = Column(Integer, primary_key=True, index=True)
    question = Column(Text)
    current_setup = Column(Text)
    requirements = Column(Text)
    response = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

class PricingEstimate(Base):
    __tablename__ = "pricing_estimates"
    
    id = Column(Integer, primary_key=True, index=True)
    data_volume_gb = Column(Float)
    queries_per_month = Column(Integer)
    storage_duration_months = Column(Integer)
    high_availability = Column(Boolean)
    backup_retention_days = Column(Integer)
    total_monthly_usd = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def create_tables():
    Base.metadata.create_all(bind=engine)
