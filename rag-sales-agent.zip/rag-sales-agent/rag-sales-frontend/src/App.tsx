import { useState, useRef, useEffect } from 'react'
import { Send, Bot, User, MessageSquare, Users, DollarSign, Settings, Zap } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import './App.css'

interface ChatMessage {
  id: string
  type: 'user' | 'bot'
  content: string
  timestamp: Date
  category?: string
  suggestions?: string[]
}

interface LeadQualification {
  company_name: string
  industry: string
  use_case: string
  data_volume: string
  timeline: string
  budget_range: string
}

interface PricingEstimate {
  data_volume_gb: number
  queries_per_month: number
  storage_duration_months: number
  high_availability: boolean
  backup_retention_days: number
}

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

function App() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      type: 'bot',
      content: "Hello! I'm your RAG Sales Assistant. I can help you with lead qualification, technical guidance on Azure vector databases, and pricing estimates for RAG applications. How can I assist you today?",
      timestamp: new Date(),
      category: 'general',
      suggestions: [
        'Qualify a new lead',
        'Get technical guidance',
        'Estimate project costs',
        'Learn about Azure vector databases'
      ]
    }
  ])
  const [inputMessage, setInputMessage] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState('chat')
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const [leadForm, setLeadForm] = useState<LeadQualification>({
    company_name: '',
    industry: '',
    use_case: '',
    data_volume: '',
    timeline: '',
    budget_range: ''
  })

  const [pricingForm, setPricingForm] = useState<PricingEstimate>({
    data_volume_gb: 100,
    queries_per_month: 1000,
    storage_duration_months: 12,
    high_availability: false,
    backup_retention_days: 7
  })

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const sendMessage = async (message: string) => {
    if (!message.trim()) return

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: message,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInputMessage('')
    setIsLoading(true)

    try {
      const response = await fetch(`${API_URL}/api/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message })
      })

      if (!response.ok) {
        throw new Error('Failed to send message')
      }

      const data = await response.json()
      
      const botMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: data.response,
        timestamp: new Date(),
        category: data.category,
        suggestions: data.suggestions
      }

      setMessages(prev => [...prev, botMessage])
    } catch (error) {
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: 'Sorry, I encountered an error. Please try again.',
        timestamp: new Date(),
        category: 'error'
      }
      setMessages(prev => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleSuggestionClick = (suggestion: string) => {
    sendMessage(suggestion)
  }

  const qualifyLead = async () => {
    setIsLoading(true)
    try {
      const response = await fetch(`${API_URL}/api/qualify-lead`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(leadForm)
      })

      if (!response.ok) {
        throw new Error('Failed to qualify lead')
      }

      const data = await response.json()
      
      const resultMessage: ChatMessage = {
        id: Date.now().toString(),
        type: 'bot',
        content: `Lead Qualification Results for ${leadForm.company_name}:

Score: ${data.score}/100
Status: ${data.qualification_status}

Recommendations:
${data.recommendations.map((rec: string) => `• ${rec}`).join('\n')}

Next Steps:
${data.next_steps.map((step: string) => `• ${step}`).join('\n')}`,
        timestamp: new Date(),
        category: 'lead_qualification'
      }

      setMessages(prev => [...prev, resultMessage])
      setActiveTab('chat')
    } catch (error) {
      console.error('Error qualifying lead:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const getPricingEstimate = async () => {
    setIsLoading(true)
    try {
      const response = await fetch(`${API_URL}/api/pricing-estimate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(pricingForm)
      })

      if (!response.ok) {
        throw new Error('Failed to get pricing estimate')
      }

      const data = await response.json()
      
      const resultMessage: ChatMessage = {
        id: Date.now().toString(),
        type: 'bot',
        content: `Azure RAG Application Pricing Estimate:

Total Monthly Cost: $${data.monthly_estimate.total_monthly_usd}

Cost Breakdown:
• PostgreSQL Compute: $${data.breakdown.postgresql_compute}
• Storage: $${data.breakdown.storage}
• Backup: $${data.breakdown.backup}
• OpenAI Embeddings: $${data.breakdown.openai_embeddings}
• OpenAI Queries: $${data.breakdown.openai_queries}

Recommendations:
${data.recommendations.map((rec: string) => `• ${rec}`).join('\n')}

Scaling Considerations:
${data.scaling_considerations.map((note: string) => `• ${note}`).join('\n')}`,
        timestamp: new Date(),
        category: 'pricing'
      }

      setMessages(prev => [...prev, resultMessage])
      setActiveTab('chat')
    } catch (error) {
      console.error('Error getting pricing estimate:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const getCategoryIcon = (category?: string) => {
    switch (category) {
      case 'lead_qualification':
        return <Users className="w-4 h-4" />
      case 'pricing':
        return <DollarSign className="w-4 h-4" />
      case 'technical':
        return <Settings className="w-4 h-4" />
      default:
        return <MessageSquare className="w-4 h-4" />
    }
  }

  const getCategoryColor = (category?: string) => {
    switch (category) {
      case 'lead_qualification':
        return 'bg-blue-100 text-blue-800'
      case 'pricing':
        return 'bg-green-100 text-green-800'
      case 'technical':
        return 'bg-purple-100 text-purple-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Bot className="w-8 h-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">RAG Sales Assistant</h1>
          </div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Your AI-powered assistant for RAG application sales. Get help with lead qualification, 
            Azure vector database guidance, and pricing estimates.
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="max-w-6xl mx-auto">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="chat" className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              Chat Assistant
            </TabsTrigger>
            <TabsTrigger value="qualify" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Lead Qualification
            </TabsTrigger>
            <TabsTrigger value="pricing" className="flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              Pricing Estimate
            </TabsTrigger>
          </TabsList>

          <TabsContent value="chat" className="mt-6">
            <Card className="h-96">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bot className="w-5 h-5" />
                  Chat with RAG Sales Assistant
                </CardTitle>
                <CardDescription>
                  Ask questions about lead qualification, technical guidance, or pricing
                </CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col h-80">
                <ScrollArea className="flex-1 pr-4">
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div key={message.id} className={`flex gap-3 ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`flex gap-3 max-w-3xl ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            message.type === 'user' ? 'bg-blue-600' : 'bg-gray-600'
                          }`}>
                            {message.type === 'user' ? (
                              <User className="w-4 h-4 text-white" />
                            ) : (
                              <Bot className="w-4 h-4 text-white" />
                            )}
                          </div>
                          <div className={`rounded-lg px-4 py-2 ${
                            message.type === 'user' 
                              ? 'bg-blue-600 text-white' 
                              : 'bg-white border shadow-sm'
                          }`}>
                            <div className="flex items-center gap-2 mb-1">
                              {message.type === 'bot' && message.category && (
                                <Badge variant="secondary" className={`text-xs ${getCategoryColor(message.category)}`}>
                                  {getCategoryIcon(message.category)}
                                  <span className="ml-1 capitalize">{message.category.replace('_', ' ')}</span>
                                </Badge>
                              )}
                            </div>
                            <p className="whitespace-pre-wrap">{message.content}</p>
                            {message.suggestions && message.suggestions.length > 0 && (
                              <div className="mt-3 flex flex-wrap gap-2">
                                {message.suggestions.map((suggestion, index) => (
                                  <Button
                                    key={index}
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleSuggestionClick(suggestion)}
                                    className="text-xs"
                                  >
                                    {suggestion}
                                  </Button>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                    {isLoading && (
                      <div className="flex gap-3 justify-start">
                        <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center">
                          <Bot className="w-4 h-4 text-white" />
                        </div>
                        <div className="bg-white border shadow-sm rounded-lg px-4 py-2">
                          <div className="flex items-center gap-2">
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-600"></div>
                            <span className="text-gray-600">Thinking...</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  <div ref={messagesEndRef} />
                </ScrollArea>
                
                <div className="flex gap-2 mt-4">
                  <Input
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    placeholder="Ask about RAG applications, lead qualification, or pricing..."
                    onKeyPress={(e) => e.key === 'Enter' && sendMessage(inputMessage)}
                    disabled={isLoading}
                  />
                  <Button 
                    onClick={() => sendMessage(inputMessage)}
                    disabled={isLoading || !inputMessage.trim()}
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="qualify" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Lead Qualification
                </CardTitle>
                <CardDescription>
                  Qualify prospects for RAG applications based on company profile and requirements
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Company Name</label>
                    <Input
                      value={leadForm.company_name}
                      onChange={(e) => setLeadForm({...leadForm, company_name: e.target.value})}
                      placeholder="Enter company name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Industry</label>
                    <Input
                      value={leadForm.industry}
                      onChange={(e) => setLeadForm({...leadForm, industry: e.target.value})}
                      placeholder="e.g., Technology, Finance, Healthcare"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Use Case</label>
                    <Input
                      value={leadForm.use_case}
                      onChange={(e) => setLeadForm({...leadForm, use_case: e.target.value})}
                      placeholder="e.g., Customer support, Document search"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Data Volume</label>
                    <Input
                      value={leadForm.data_volume}
                      onChange={(e) => setLeadForm({...leadForm, data_volume: e.target.value})}
                      placeholder="e.g., 100GB, 1TB, 10TB"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Timeline</label>
                    <Input
                      value={leadForm.timeline}
                      onChange={(e) => setLeadForm({...leadForm, timeline: e.target.value})}
                      placeholder="e.g., Immediate, 3 months, 6 months"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Budget Range</label>
                    <Input
                      value={leadForm.budget_range}
                      onChange={(e) => setLeadForm({...leadForm, budget_range: e.target.value})}
                      placeholder="e.g., $10k-50k, $100k-500k"
                    />
                  </div>
                </div>
                <Button 
                  onClick={qualifyLead}
                  disabled={isLoading || !leadForm.company_name}
                  className="w-full"
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Qualify Lead
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pricing" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  Azure Pricing Estimate
                </CardTitle>
                <CardDescription>
                  Get cost estimates for running RAG applications on Azure
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Data Volume (GB)</label>
                    <Input
                      type="number"
                      value={pricingForm.data_volume_gb}
                      onChange={(e) => setPricingForm({...pricingForm, data_volume_gb: parseFloat(e.target.value)})}
                      placeholder="100"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Queries per Month</label>
                    <Input
                      type="number"
                      value={pricingForm.queries_per_month}
                      onChange={(e) => setPricingForm({...pricingForm, queries_per_month: parseInt(e.target.value)})}
                      placeholder="1000"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Storage Duration (Months)</label>
                    <Input
                      type="number"
                      value={pricingForm.storage_duration_months}
                      onChange={(e) => setPricingForm({...pricingForm, storage_duration_months: parseInt(e.target.value)})}
                      placeholder="12"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Backup Retention (Days)</label>
                    <Input
                      type="number"
                      value={pricingForm.backup_retention_days}
                      onChange={(e) => setPricingForm({...pricingForm, backup_retention_days: parseInt(e.target.value)})}
                      placeholder="7"
                    />
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="high_availability"
                    checked={pricingForm.high_availability}
                    onChange={(e) => setPricingForm({...pricingForm, high_availability: e.target.checked})}
                    className="rounded"
                  />
                  <label htmlFor="high_availability" className="text-sm font-medium">
                    High Availability (2x cost for redundancy)
                  </label>
                </div>
                <Button 
                  onClick={getPricingEstimate}
                  disabled={isLoading}
                  className="w-full"
                >
                  <DollarSign className="w-4 h-4 mr-2" />
                  Get Pricing Estimate
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default App
